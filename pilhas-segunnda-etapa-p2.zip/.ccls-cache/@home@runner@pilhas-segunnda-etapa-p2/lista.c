#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "lista.h"
struct _no{
  char chave[20];
  float valor;
  struct _no* prox;
};
struct _lista{
  struct _no* inicio;
};
static struct _no* lista_buscar(Lista *lista, char* chave){
  struct _no* prox = lista->inicio;
  while(prox){
    if (strcmp(chave,prox->chave)==0){
      return prox;
    }
    prox=prox->prox;
  }
  return NULL;
};
Lista* criar_lista(){
  Lista* lista= calloc(1,sizeof(Lista));
  lista->inicio=NULL;
  return lista;
}
void lista_append(Lista* lista, char* chave,float valor){
  struct _no * no = calloc(1,sizeof(struct _no));
  strcpy(no->chave,chave);
  no->valor=valor;
  no->prox=lista->inicio;
  lista->inicio=no;
}
float lista_get(Lista* lista, char* chave){
  struct _no*x;
  if((x = lista_buscar(lista,chave))!=NULL){
    return x->valor;
  }
  return -1;
}
void lista_set(Lista* lista, char* chave, float valor){
  struct _no*x;
  if((x = lista_buscar(lista,chave))!=NULL){
    x->valor=valor;
  }
}
int lista_exist(Lista* lista, char* chave){
  return lista_buscar(lista,chave)!=NULL;
}
void lista_print(Lista* lista){
  struct _no* prox = lista->inicio;
  if(prox){
    printf("\t(i) Lista:\n");
    while(prox){
    printf("\t\t%s = %.2f\n",prox->chave,prox->valor);
    prox=prox->prox;
    }
  }
}
