#include <stdio.h>
#include "interpretador.h"
#include "pilha.h"

static void REPL(){
  char input[1024];
  while(1){
    printf("> ");
    if(!fgets(input,sizeof(input),stdin)){
      printf("\n");
      break;
    }
    interpretar(input,1); 
}
int main () {
  gerar_pilha(10);
  gerar_lista();
  REPL();
  return 0;
}