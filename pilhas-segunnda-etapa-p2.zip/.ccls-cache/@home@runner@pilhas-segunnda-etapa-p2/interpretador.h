void interpretar (const char *input, int imprimir);
void gerar_pilha (int quant_itens);
void gerar_lista ();