#include "pilha.h"
#include "stdio.h"
#include "stdlib.h"
struct _pilha {
  float * itens;
  int ultimo;
};
Pilha* criar_pilha(int tamanho){
  Pilha* pilha = (Pilha*) malloc (sizeof(struct _pilha));
  pilha->itens = (int*) malloc(sizeof(int) * tamanho);
  pilha->ultimo = 0;
  return pilha;
}
void pilha_incluir(Pilha* pilha, float valor){
  pilha->itens[pilha->ultimo++] = valor;
}
float pilha_remover (Pilha *pilha){
  return pilha->itens[--pilha->ultimo];
}
void pilha_imprimir(Pilha* pilha){
  if(pilha->ultimo!=0){
    printf ("\t(i) Pilha:\n");
    for (int i=0; i < pilha->ultimo; i++) {
      printf ("\t\t%.2f\n", pilha->itens[i]);
    }
  }
}
