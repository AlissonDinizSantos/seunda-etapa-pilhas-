#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "interpretador.h"
#include "pilha.h"
#include "lista.h"
Pilha *pilha;
Lista *lista;
void gerar_lista (){
  lista = criar_lista();
}
void gerar_pilha (int quant_itens) {
  pilha = criar_pilha(quant_itens);
}
void interpretar (const char *input, int imprimir) {
  float a=0.0,b=0.0;
  char comando[10];
  char argumento[20];
  sscanf (input, "%s%s",comando,argumento);
  if(strcmp(comando,"push")==0){
    if(sscanf(argumento,"%f",&a)==0){
      a=lista_get(lista,argumento);
    }
    pilha_incluir(pilha,a);
  } else if(strcmp(comando,"pop")==0){
    a=pilha_remover(pilha);
    if(lista_exist(lista,argumento)){
      lista_set(lista,argumento,a);
    } else {
      lista_append(lista,argumento,a);
    }
  } else if(strcmp(comando,"print")==0){
    printf("%.1f\n",pilha_remover(pilha));
  } else {
    a=pilha_remover(pilha);
    b=pilha_remover(pilha);
    if(strcmp(comando,"add")==0){
      pilha_incluir(pilha,a+b);
    } else if(strcmp(comando,"sub")==0){
      pilha_incluir(pilha,a-b);
    } else if(strcmp(comando,"div")==0){
      pilha_incluir(pilha,a/b);
    } else if(strcmp(comando,"mul")==0){
      pilha_incluir(pilha,a*b);
    } else {
      pilha_incluir(pilha,b);
      pilha_incluir(pilha,a);
      return printf("Qual Comando: push, pop, add, sub, mul, div, print.\n");
    }
  }
  if(imprimir!=0){
    lista_print(lista);
    pilha_imprimir(pilha);
  }
}