typedef struct _pilha Pilha;
Pilha* criar_pilha(int tamanho);
void pilha_incluir(Pilha* pilha, float valor);
float pilha_remover(Pilha* pilha);
void pilha_imprimir(Pilha* pilha);