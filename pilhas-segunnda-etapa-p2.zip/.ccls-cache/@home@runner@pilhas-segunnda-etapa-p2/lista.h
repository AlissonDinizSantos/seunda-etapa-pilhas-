typedef struct _lista Lista;
Lista* criar_lista();
void lista_append(Lista* lista, char* chave,float valor);
float lista_get(Lista* lista, char* chave);
void lista_set(Lista* lista, char* chave, float valor);
int lista_exist(Lista* lista, char* chave);
void lista_print(Lista* lista);